export const {
	NODE_ENV = 'development',
	PORT = '4000',
	CLIENT_URI = 'http://localhost:3000',
	JWT_SECRET = 'this is a JWT secret placeholder',
	DATABASE_URL,
} = process.env;
