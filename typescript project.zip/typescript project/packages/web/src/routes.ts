export const routes = {
	dashboard: { path: '/' },
	register: { path: '/register' },
	login: { path: '/login' },
	logout: { path: '/logout' },
};
