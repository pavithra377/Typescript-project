export const queryKeys = {
	ME: '/auth/me',
};
