# Library Management System

a library management system built with PERN stack with TypeScript
